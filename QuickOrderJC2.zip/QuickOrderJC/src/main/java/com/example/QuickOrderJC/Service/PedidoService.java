package com.example.QuickOrderJC.Service;

import com.example.QuickOrderJC.Model.Pedido;
import com.example.QuickOrderJC.Model.Estado;
import com.example.QuickOrderJC.Repository.PedidoRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;

    // Inyección por constructor
    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    public List<Pedido> obtenerTodos() {
        return pedidoRepository.findAll();
    }

    public Pedido obtenerPorId(Long id) {
        return pedidoRepository.findById(id);
    }

    public Pedido guardar(Pedido pedido) {
        // REGLA DE NEGOCIO: La fecha se asigna automáticamente al registrar [cite: 38, 90, 91]
        if (pedido.getId() == null) {
            pedido.setFechaPedido(LocalDate.now());
        }

        // Aquí podrías agregar validaciones manuales si no usas @Valid
        return pedidoRepository.save(pedido);
    }

    public boolean eliminar(Long id) {
        return pedidoRepository.deleteById(id);
    }

    // OPERACIÓN DE PROCESAMIENTO: Filtro por estado [cite: 109, 110]
    public List<Pedido> listarPorEstado(Estado estado) {
        return pedidoRepository.findAll().stream()
                .filter(p -> p.getEstado().equals(estado))
                .collect(Collectors.toList());
    }
}
