package com.example.QuickOrderJC.Controller;

import com.example.QuickOrderJC.Model.Pedido;
import com.example.QuickOrderJC.Model.Estado;
import com.example.QuickOrderJC.Service.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @GetMapping
    public List<Pedido> listarTodos() {
        return pedidoService.obtenerTodos();
    }

    @PostMapping
    public ResponseEntity<Pedido> crear(@RequestBody Pedido pedido) {
        return new ResponseEntity<>(pedidoService.guardar(pedido), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pedido> buscarPorId(@PathVariable Long id) {
        Pedido p = pedidoService.obtenerPorId(id);
        return (p != null) ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        return pedidoService.eliminar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    // --- MÉTODO CORREGIDO ---
    @PutMapping("/{id}")
    public ResponseEntity<Pedido> actualizar(@PathVariable Long id, @RequestBody Pedido pedido) {
        // Buscamos si existe antes de actualizar
        Pedido existente = pedidoService.obtenerPorId(id);
        if (existente == null) {
            return ResponseEntity.notFound().build();
        }

        // Seteamos el ID del path al objeto para asegurar que actualice el correcto
        pedido.setId(id);
        Pedido actualizado = pedidoService.guardar(pedido); // Usualmente guardar() maneja update si el ID existe

        return ResponseEntity.ok(actualizado);
    }

    @GetMapping("/estado/{estado}")
    public List<Pedido> filtrarPorEstado(@PathVariable Estado estado) {
        return pedidoService.listarPorEstado(estado);
    }
}