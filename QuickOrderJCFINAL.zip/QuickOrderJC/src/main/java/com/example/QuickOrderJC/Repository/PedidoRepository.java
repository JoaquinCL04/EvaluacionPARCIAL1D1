package com.example.QuickOrderJC.Repository;

import com.example.QuickOrderJC.Model.Pedido;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PedidoRepository {
    private List<Pedido> pedidos = new ArrayList<>();
    private Long currentId = 1L;

    public List<Pedido> findAll() { return pedidos; }

    public Pedido save(Pedido pedido) {
        if (pedido.getId() == null) {
            pedido.setId(currentId++);
            pedidos.add(pedido);
        } else {
            // Lógica para actualizar (PUT)
            pedidos.removeIf(p -> p.getId().equals(pedido.getId()));
            pedidos.add(pedido);
        }
        return pedido;
    }

    public Pedido findById(Long id) {
        return pedidos.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
    }

    public boolean deleteById(Long id) {
        return pedidos.removeIf(p -> p.getId().equals(id));
    }
}
