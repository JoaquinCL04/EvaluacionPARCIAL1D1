package com.example.QuickOrderJC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickOrderJcApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickOrderJcApplication.class, args);
	}

}
