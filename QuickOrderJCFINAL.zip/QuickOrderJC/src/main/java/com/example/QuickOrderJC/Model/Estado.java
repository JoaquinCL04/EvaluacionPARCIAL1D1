package com.example.QuickOrderJC.Model;

/** Enumeración que define los estados posibles de un pedido según el flujo de negocio */
public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}